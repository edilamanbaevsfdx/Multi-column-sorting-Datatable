import { LightningElement, api } from 'lwc';

export default class DatatableImage extends LightningElement {
    @api value;
}
